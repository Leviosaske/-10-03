﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using case_cource;

namespace cource_consl
{
    class Program
    {
        
        public static Class1 cls = new Class1();
        static void Main(string[] args)
        {
            List<Mark> marks = new List<Mark>();

            List<Student> students = new List<Student>
            {
                new Student(2018,818,"Козлов Марк Фёдорович"),
                new Student(2018,818,"Шишкин Павел Викторович"),
                new Student(2019,819,"Никитин Иван Александрович"),
                new Student(2019,819,"Никитин Иван Александрович"),
                new Student(2020,820,"Кудряшова Полина Александровна"),
                new Student(2020,820,"Уткина Алиса Дмитриевна"),
                new Student(2021,821,"Бычков Максим Эмильевич"),
                new Student(2021,821,"Яковлев Андрей Максимович"),
                new Student(2022,822,"Романова Алиса Марковна"),
                new Student(2022,822,"Курочкина Анна Игоревна")
            };

            //Заполнение оценками
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.05.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.03.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.07.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.01.2022"), students));

            //Вывод всех оценок
            Console.WriteLine("Все оценки");
            foreach (Mark m in marks)
            {
                Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.estimatoin} - {m.student.fio}");
            }
            Console.WriteLine();

            Console.WriteLine("Прогулы за месяцы");
            //Вывод прогулов за месяцы
            foreach (int i in cls.GetCountTruancy(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();

            //Вывод болезней за месяц
            Console.WriteLine("Болезни за месяцы");
            foreach (int i in cls.GetCountDisease(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();

            //Студенческие билеты студентов
            Console.WriteLine("Номера студенческих билетов");
            foreach (Student std in students)
            {
                Console.WriteLine(cls.GetStudNumber(std));
            }
            Console.WriteLine();

            //Среднее арифметическое оценок в меньшую сторону
            Console.WriteLine("Среднее арифметическое");
            Console.WriteLine(cls.MinAVG(new string[6] { "4", "5", "5", "б", "п", " " }));
            Console.ReadKey();

        }
    }
}
