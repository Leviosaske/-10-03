﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace case_cource
{
    public class Class1
    {
        Random rnd = new Random();
        public double MinAVG(string[] marks)
        {
            double i = 0;
            double sum = 0;
            foreach (string mark in marks)
            {
                if (int.TryParse(mark, out int est))
                {
                    sum += est;
                    i++;
                }
            }
            string res = (sum / i).ToString();
            if (res.Contains(','))
                return double.Parse(res.Substring(0, res.IndexOf(',') + 2));
            else return double.Parse(res);
        }
        public int[] GetCountTruancy(List<Mark> marks)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var ttt = (from m in marks
                       group m by m.date.Month into g
                       select new { date = g.Key }).ToList();
            foreach (var t in ttt)
            {
                int prom = marks.FindAll(m => m.date.Month == t.date && m.estimatoin == "н").Count;
                res.Add(t.date, prom);
            }
            return res.Select(x => x.Value).ToArray();
        }
        public List<Mark> GetMarks(DateTime now, List<Student> students)
        {
        
            List<string> estimation = new List<string>() { "2", "3", "4", "5", "п", "н", "б", " " };
            List<Mark> marks = new List<Mark>();
            int len = estimation.Count;

            foreach (Student student in students)
            {
                for (int i = 0; i < 10; i++)
                {
                    int r = rnd.Next(len);
                    marks.Add(new Mark
                        (
                            now.AddDays(i),
                            estimation[r],
                            student)
                        );
                }
            }
            return marks;
        }
        public int[] GetCountDisease(List<Mark> marks)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var ttt = (from m in marks
                       group m by m.date.Month into g
                       select new { date = g.Key }).ToList();
            foreach (var t in ttt)
            {
                int prom = marks.FindAll(m => m.date.Month == t.date && m.estimatoin == "б").Count;
                res.Add(t.date, prom);
            }
            return res.Select(x => x.Value).ToArray();
        }
    }
    public class Student
    {
        public int group { get; set; }
        public int year { get; set; }
        public string fio { get; set; }
        public Student(int y,int g,string Fio)
        {
            year = y;
            fio = Fio;
            group = g;
        }
     }
    public class Mark
    {
        public DateTime date { get; set; }
        public string estimatoin { get; set;}
        public Student student { get; set; }
        public Mark(DateTime dat,string est,Student stud)
        {
            date = dat;
            estimatoin = est;
            student = stud;
        }
    }
}
